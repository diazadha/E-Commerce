<span class="top-left">
	<i class="fa fa-envelope"></i> <?php _e('support@youriste.com','seller') ?>
</span>
<span class="top-left">
	<i class="fa fa-phone"></i> <?php _e('1800 100 123','seller'); ?>
</span>	
